app.register.controller('createInvoiceController', function($scope) {
	$scope.createNew = function() {
		alert('Create new invoice from controller');
	}


});