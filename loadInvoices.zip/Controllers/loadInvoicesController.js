app.register.controller('loadInvoicesController', function($scope, $http) {
	$http.get('https://rambasemockapi.herokuapp.com/api/invoices').then(function(res) {
		$scope.invoices = res.data.invoices;
	});


});