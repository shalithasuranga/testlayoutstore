app.register.controller('loadInvoicesController', function($scope, $http) {
	$http.get('http://localhost:5005/api/invoices').then(function(res) {
		$scope.invoices = res.data.invoices;
	});


});