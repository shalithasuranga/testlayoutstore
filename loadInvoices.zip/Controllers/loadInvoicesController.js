app.register.controller('loadInvoicesController', function($scope, $http) {
	$http.get('http://' + window.baseApi + '/api/sales/invoices').then(function(res) {
		$scope.invoices = res.data.invoices;
	});


});