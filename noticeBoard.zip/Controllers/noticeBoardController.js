app.register.controller('noticeBoardController', function($scope) {
	$scope.save = function() {
		alert('Save note from controller');
	}

	$scope.clear = function($event) {
		 $scope.text = '';
	}


});