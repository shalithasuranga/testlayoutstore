app.register.controller('salesOrdersController', function($scope, $http) {

	$scope.orderId = 'N/A';

	$http.get('http://' + window.baseApi + '/api/sales/orders').then(function(res) {
		$scope.orders = res.data.SalesOrders.SalesOrder;
	});

	$scope.loadSalesOrderItems = function(orderId) {
		$scope.orderId = orderId;
		$http.get('http://' + window.baseApi + '/api/sales/orderitem/' + orderId).then(function(res) {
			$scope.orderItems = res.data.SalesOrderItems.SalesOrderItem;
		});
	}


});